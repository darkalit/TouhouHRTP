#include "Player.h"


Player::Player(GLFWwindow* window, const uint32& screenWidth, const uint32& screenHeight)
	:	_Window(window)
{
	this->_screenWidth = screenWidth;
	this->_screenHeight = screenHeight;
	this->_Texture.texFromImage("Textures/reimu.png");
	this->initTextures();
	this->_Temp = this->_Sprites["stand"].at(0);
}

Player::~Player()
{
	for (auto& kv : this->_Sprites)
		for (auto& sprite : kv.second)
			delete sprite;
}

auto Player::stand	() -> bool
{
	this->_Temp = this->_Sprites["stand"].at(0);
	return true;
}

auto Player::run	() -> bool
{
	this->_iter %= this->_Sprites["run"].size();
	this->_Temp = this->_Sprites["run"].at(_iter);
	this->_time++;
	if (this->_time > 30.0f)
	{
		this->_time = 0;
		this->_iter++;
	}
	return true;
}

auto Player::slide	() -> bool
{
	this->_iter %= this->_Sprites["slide"].size();
	this->_Temp = this->_Sprites["slide"].at(_iter);
	this->_time++;
	if (this->_time > 30.0f)
	{
		_time = 0.0f;
		_iter++;
	}

	return true;
}

void Player::initTextures()
{
	this->_Sprites["stand"] = std::vector<Sprite*>
	{
		new Sprite(this->_Texture, glm::ivec4(  5, 0,  28, 34),	glm::ivec2(_screenWidth, _screenHeight)) 
	};
	this->_Sprites["run"] = std::vector<Sprite*>
	{
		new Sprite(this->_Texture, glm::ivec4( 66, 0,  95, 34),	glm::ivec2(_screenWidth, _screenHeight)),
		new Sprite(this->_Texture, glm::ivec4( 98, 0, 127, 34),	glm::ivec2(_screenWidth, _screenHeight)) 
	};
	this->_Sprites["slide"] = std::vector<Sprite*>
	{
		new Sprite(this->_Texture, glm::ivec4(162, 0, 209, 34), glm::ivec2(_screenWidth, _screenHeight)),
		new Sprite(this->_Texture, glm::ivec4(212, 0, 259, 34), glm::ivec2(_screenWidth, _screenHeight))
	};	
}

void Player::updateInput(const float32& deltaTime)//(GLFWwindow* window, int key, int scancode, int action, int mods)
{	
	if (!(glfwGetKey(_Window, GLFW_KEY_RIGHT) || glfwGetKey(_Window, GLFW_KEY_LEFT)))
	{
		this->stand();
		this->setPos(this->getPos().x, this->getPos().y);
		this->setScale(glm::vec2(1.0f, 1.0f));
	}
	else if (glfwGetKey(_Window, GLFW_KEY_LEFT) && !_animFlagLS && !_animFlagRS)
	{
		this->run();
		this->setPos(this->getPos().x - 0.4f, floor(this->getPos().y));
		if (this->getPos().x < this->getSize().x + 1.0f)
			this->setPos(floor(this->getSize().x + 1.0f), this->getPos().y);
		this->setScale(glm::vec2(1.0f, 1.0f));
	}
	else if (glfwGetKey(_Window, GLFW_KEY_RIGHT) && !_animFlagRS && !_animFlagLS)
	{
		this->run();
		this->setPos(this->getPos().x + 0.4f, floor(this->getPos().y));
		if (this->getPos().x > (this->_screenWidth - this->getSize().x))
			this->setPos(floor(this->_screenWidth - this->getSize().x), this->getPos().y);
		this->setScale(glm::vec2(-1.0f, 1.0f));
	}
	if (((glfwGetKey(_Window, GLFW_KEY_X) && glfwGetKey(_Window, GLFW_KEY_LEFT)) || _animFlagLS) && _animFlagRS == false)
	{
		this->slide();
				
		if (_animFlagLS == false)
			this->_animTime = 0.0f;

		if (this->_animTime * deltaTime < 0.5f)
		{
			_animFlagLS = true;
			this->setPos(floor(this->getPos().x - 1.0f), floor(this->getPos().y));
		}
		else
			_animFlagLS = false;
		this->_animTime++;

		if (this->getPos().x < this->getSize().x + 1.0f)
			this->setPos(floor(this->getSize().x + 1.0f), this->getPos().y);

		this->setScale(glm::vec2(1.0f, 1.0f));
	}
	else if (((glfwGetKey(_Window, GLFW_KEY_X) && glfwGetKey(_Window, GLFW_KEY_RIGHT)) || _animFlagRS) && _animFlagLS == false)
	{
		this->slide();
		if (!_animFlagRS)
			this->_animTime = 0.0f;

		if (this->_animTime * deltaTime < 0.5f)
		{
			_animFlagRS = true;
			this->setPos(floor(this->getPos().x + 1.0f), floor(this->getPos().y));
		}
		else
			_animFlagRS = false;
		this->_animTime++;

		if (this->getPos().x > (this->_screenWidth - this->getSize().x))
			this->setPos(floor(this->_screenWidth - this->getSize().x), this->getPos().y);

		this->setScale(glm::vec2(-1.0f, 1.0f));
	}	
}

void Player::update(const float32& deltaTime)
{
	//glfwSetKeyCallback(this->window, this->updateInput);
	this->updateInput(deltaTime);
}

void Player::draw()
{
	this->_Temp->draw(this->_pos, this->_scale);
}
