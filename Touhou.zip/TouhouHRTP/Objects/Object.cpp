#include "Object.h"

Object::Object()
{ }

Object::~Object()
{ }

void Object::setPos		(const float32& x, const float32& y)
{
	this->_pos = glm::vec2(x, y);
}

void Object::move		(const float32& x, const float32& y)
{
	this->setPos(this->getPos().x + x, this->getPos().y + y);
}

void Object::setRot		(const float32& angle)
{
	this->_angle = angle;
}

void Object::setScale	(const glm::vec2& scale)
{
	this->_scale = scale;
}

auto Object::getPos		() -> glm::vec2 const
{
	return this->_pos;
}

auto Object::getEdges	() -> glm::ivec4 const
{
	return this->_Temp->getEdges();
}

auto Object::getBounds	() -> Rect
{
	this->_Bounds.bottomLeft	= glm::vec2(_pos.x - static_cast<float32>(this->getEdges().z - this->getEdges().x) / 2.0f,
											_pos.y - static_cast<float32>(this->getEdges().w - this->getEdges().y) / 2.0f);
	this->_Bounds.topLeft		= glm::vec2(_pos.x - static_cast<float32>(this->getEdges().z - this->getEdges().x) / 2.0f,
											_pos.y + static_cast<float32>(this->getEdges().w - this->getEdges().y) / 2.0f);
	this->_Bounds.topRight		= glm::vec2(_pos.x + static_cast<float32>(this->getEdges().z - this->getEdges().x) / 2.0f,
											_pos.y + static_cast<float32>(this->getEdges().w - this->getEdges().y) / 2.0f);
	this->_Bounds.bottomRight	= glm::vec2(_pos.x + static_cast<float32>(this->getEdges().z - this->getEdges().x) / 2.0f,
											_pos.y - static_cast<float32>(this->getEdges().w - this->getEdges().y) / 2.0f);
	return this->_Bounds;
}

auto Object::getSize	() -> glm::vec2 const
{
	return this->_Temp->getSize();
}

bool Object::checkIntersect(Object& object)
{
	if (this->getBounds().topLeft.x > object.getBounds().bottomRight.x ||
		this->getBounds().topLeft.y < object.getBounds().bottomRight.y ||
		this->getBounds().bottomRight.x < object.getBounds().topLeft.x ||
		this->getBounds().bottomRight.y > object.getBounds().topLeft.y)
		return false;
	else
		return true;
}
