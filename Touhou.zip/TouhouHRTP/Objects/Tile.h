#pragma once
#include "Object.h"

class Tile : public Object 
{
public:
	Tile	(const uint32& screenWidth, const uint32& screenHeight, const int8& phase);
	~Tile	();

	auto flip		()	-> bool;
	auto getFlip	()	-> bool;

	void update		(const float32& deltaTime)	override;
	void draw		()							override;

private:
	char _flipF = false;

	void initTextures() override;
};

