#include "Ball.h"

Ball::Ball(const uint32& screenWidth, const uint32& screenHeight)
{
	this->_screenWidth	= screenWidth;
	this->_screenHeight = screenHeight;
	this->_Texture.texFromImage("Textures/tiles.png");
	this->initTextures();
	this->_Temp = this->_Sprites["ball"].at(this->_iter);
}

Ball::~Ball()
{
	for (auto& kv : this->_Sprites)
		for (auto& sprite : kv.second)
			delete sprite;
}

auto Ball::fall(const float32& deltaTime) -> bool
{
	this->_iter %= this->_Sprites["ball"].size();

	this->_Temp = this->_Sprites["ball"].at(_iter);
	this->_time++;
	if (this->_time * deltaTime > (1.0f / sqrt(fabs(this->_yVel))) && this->_xVel < 0.0f)
	{
		this->_time = 0.0f;
		this->_iter++;
	}
	if (this->_time * deltaTime > (1.0f / sqrt(fabs(this->_yVel))) && this->_xVel > 0.0f)
	{
		this->_time = 0.0f;
		this->_iter--;
	}
	return true;
}

auto Ball::getVel		() -> glm::vec2
{
	return glm::vec2(_xVel, _yVel);
}

void Ball::setVel		(const float32& xVel, const float32& yVel)
{
	this->_xVel = xVel;
	this->_yVel = yVel;
}

void Ball::initTextures	()
{
	this->_Sprites["ball"] = std::vector<Sprite*>
	{
		new Sprite(this->_Texture, glm::ivec4(102, 100, 128, 126), glm::ivec2(_screenWidth, _screenHeight)),
		new Sprite(this->_Texture, glm::ivec4(102, 127, 128, 153), glm::ivec2(_screenWidth, _screenHeight)),
		new Sprite(this->_Texture, glm::ivec4(102, 154, 128, 180), glm::ivec2(_screenWidth, _screenHeight)),
		new Sprite(this->_Texture, glm::ivec4(102, 181, 128, 207), glm::ivec2(_screenWidth, _screenHeight)) 
	};
}

void Ball::update(const float32& deltaTime)
{
	this->fall(deltaTime);
	this->setPos(this->getPos().x + this->_xVel * deltaTime, this->getPos().y + this->_yVel * deltaTime);

	this->_yVel += this->_gravity * deltaTime;
	if (this->getPos().y < this->getSize().y + 1.0f)
	{
		this->_yVel = -this->_yVel * this->_eLoss;
		this->setPos(this->getPos().x, this->getSize().y + 2.0f);
	}
	if (this->getPos().y > (this->_screenHeight - this->getSize().x))
	{
		this->_yVel = -this->_yVel * this->_eLoss;
		this->setPos(this->getPos().x, this->getPos().y - 1.0f);
	}
	if (this->getPos().x > (this->_screenWidth - this->getSize().x))
	{
		this->_xVel = -this->_xVel;
		this->setPos(this->getPos().x - 1.0f, this->getPos().y);
	}
	if (this->getPos().x < this->getSize().x)
	{
		this->_xVel = -this->_xVel;
		this->setPos(this->getPos().x + 1.0f, this->getPos().y);
	}
}

void Ball::draw()
{
	this->_Temp->draw(this->_pos);
}
