#include "Tile.h"

Tile::Tile	(const uint32& screenWidth, const uint32& screenHeight, const int8& phase)
{
	this->_screenWidth = screenWidth;
	this->_screenHeight = screenHeight;
	this->_Texture.texFromImage("Textures/tiles.png");
	this->initTextures();
	this->_Temp = this->_Sprites[std::to_string(phase)].at(0);
}

Tile::~Tile	()
{
	for (auto& kv : this->_Sprites)
		for (auto& sprite : kv.second)
			delete sprite;
}

auto Tile::flip			() -> bool
{
	return (_flipF = true);
}

auto Tile::getFlip		() -> bool
{
	return _flipF == 2 ? true : false;
}

void Tile::initTextures	()
{
	this->_Sprites["1"] = std::vector<Sprite*>
	{
		new Sprite(this->_Texture, glm::ivec4(101, 450, 131, 480), glm::ivec2(this->_screenWidth, this->_screenHeight)),
		new Sprite(this->_Texture, glm::ivec4(101, 480, 131, 510), glm::ivec2(this->_screenWidth, this->_screenHeight)),
		new Sprite(this->_Texture, glm::ivec4(101, 510, 131, 540), glm::ivec2(this->_screenWidth, this->_screenHeight))
	};
}

void Tile::update		(const float32& deltaTime)
{
	if (this->_flipF) 
	{	
		if (this->_iter >= this->_Sprites["1"].size())
		{
			this->_flipF = 2;
			this->_iter = 0;
		}
		this->_Temp = this->_Sprites["1"].at(_iter);
		this->_time++;
		if (this->_time > 120.0f)
		{
			this->_time = 0.0f;
			this->_iter++;
		}
		
	}	
}

void Tile::draw			()
{
	this->_Temp->draw(this->_pos);
}
