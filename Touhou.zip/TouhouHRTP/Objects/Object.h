#pragma once
#include "../Image/Sprite.h"

class Object
{
public:
	Object();
	virtual ~Object();

	virtual void setPos		(const float32& x, const float32& y);
	virtual void move		(const float32& x, const float32& y);
	virtual void setRot		(const float32& angle);
	virtual void setScale	(const glm::vec2& scale);

	virtual auto getPos			() -> glm::vec2 const;
	virtual auto getEdges		() -> glm::ivec4 const;
	virtual auto getBounds		() -> Rect;
	virtual auto getSize		() -> glm::vec2 const;
	virtual auto checkIntersect	(Object& object) -> bool;

	virtual void update	(const float32& deltaTime)	= 0;
	virtual void draw	()							= 0;

protected:
	std::map<std::string, std::vector<Sprite*>> _Sprites;
	Sprite*		_Temp;
	glm::vec2	_pos;
	glm::vec2	_scale;
	Rect		_Bounds;
	float32		_angle; 

	float32		_time			= 0.0f;
	uint32		_screenWidth, 
				_screenHeight;
	uint32		_iter			= 0;
	Texture		_Texture;

	virtual void initTextures() = 0;
};

