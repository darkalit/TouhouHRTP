#pragma once
#include "Object.h"

class Player : public Object
{
public:
	Player	(GLFWwindow* window, const uint32& screenWidth, const uint32& screenHeight);
	~Player	();

	auto stand		()	-> bool;
	auto run		()	-> bool;
	auto attack1	()	-> bool;
	auto attack2	()	-> bool;
	auto slide		()	-> bool;
	auto dead		()	-> bool;
	
	void updateInput(const float32& deltaTime);//(GLFWwindow* window, int key, int scancode, int action, int mods);
	void update		(const float32& deltaTime)	override;
	void draw		()							override;

private:
	GLFWwindow* _Window;
	float		_animTime	= 0.0f;
	bool		_animFlagLS = false;
	bool		_animFlagRS = false;

	void initTextures() override;
};

