#pragma once
#include "Object.h"

class Ball : public Object
{
public:
	Ball	(const uint32& screenWidth, const uint32& screenHeight);
	~Ball	();

	auto fall	(const float32& deltaTime)	-> bool;
	auto getVel	()							->glm::vec2;
	void setVel	(const float32& xVel, const float32& yVel);

	void update	(const float32& deltaTime)	override;
	void draw	()							override;

private:
	float32 _gravity	= -900.0f, 
			_yVel		= 0.0f, 
			_xVel		= 10.0f, 
			_eLoss		= 0.8f;
	void initTextures()						override;
};

