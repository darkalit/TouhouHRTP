#include "Sprite.h"

//#define STB_IMAGE_IMPLEMENTATION
//#include "stb_image.h"

Sprite::Sprite(const Texture& texture, GLFWwindow* window, const glm::ivec4& rect, const bool& centering)
	:	
	shader	(Shader(glsl::vSprite, glsl::fSprite)), 
	texture	(texture), 
	rect	(rect),
	size	(glm::ivec2(texture.width, texture.height)), 
	pos		(glm::vec2(0.0f))
{
	int winSizeX, winSizeY;
	glfwGetFramebufferSize(window, &winSizeX, &winSizeY);
	this->proj	= glm::ortho(0.0f, static_cast<float32>(winSizeX), static_cast<float32>(winSizeY), 0.0f, -1.0f, 1.0f);
	this->model = glm::mat4(1.0f);
	this->shader.use();
	this->shader.setMat4("model", this->model);
	this->shader.setMat4("projection", this->proj);
	loadSprite(texture, centering);
}

Sprite::Sprite(const Texture& texture, const glm::ivec4& rect, const glm::ivec2& customSize, const bool& centering)
	:	
	shader	(Shader(glsl::vSprite, glsl::fSprite)), 
	texture	(texture), 
	rect	(rect), 
	size	(glm::ivec2(texture.width, texture.height)), 
	pos		(glm::vec2(0.0f))
{
	this->proj = glm::ortho(0.0f, static_cast<float32>(customSize.x), static_cast<float32>(customSize.y), 0.0f, -1.0f, 1.0f);
	this->model = glm::mat4(1.0f);
	this->shader.use();
	this->shader.setMat4("model", this->model);
	this->shader.setMat4("projection", this->proj);
	//glGenTextures(1, &this->texture.ID);
	loadSprite(texture, centering);
}

void Sprite::loadSprite(const Texture& texture, const bool& centering)
{
	if (centering)
	{
		float32 halfx	= static_cast<float32>(this->rect.z - this->rect.x) / 2.0f, 
				halfy	= static_cast<float32>(this->rect.w - this->rect.y) / 2.0f;
		float32 x		= static_cast<float32>(this->rect.z - this->rect.x) / 2.0f, 
				y		= static_cast<float32>(this->rect.w - this->rect.y) / 2.0f;
		//float halfx = (float)this->size.x / 2.0f, halfy = (float)this->size.y / 2.0f;
		float32 quad[] = {
			// positions         // texcoords
			halfx,  halfy, static_cast<float32>(this->rect.z) / this->size.x, static_cast<float32>(this->rect.y) / this->size.y,
		   -halfx, -halfy, static_cast<float32>(this->rect.x) / this->size.x, static_cast<float32>(this->rect.w) / this->size.y,
		   -halfx,  halfy, static_cast<float32>(this->rect.x) / this->size.x, static_cast<float32>(this->rect.y) / this->size.y,

		   -halfx, -halfy, static_cast<float32>(this->rect.x) / this->size.x, static_cast<float32>(this->rect.w) / this->size.y,
			halfx,  halfy, static_cast<float32>(this->rect.z) / this->size.x, static_cast<float32>(this->rect.y) / this->size.y,
			halfx, -halfy, static_cast<float32>(this->rect.z) / this->size.x, static_cast<float32>(this->rect.w) / this->size.y
		};
		unsigned int j = 0;
		for (auto& i : quad)
		{
			quadV[j++] = i;
		}
	}		
	else
		float32 quad[] = {
			// positions													// texcoords
			0.0f,							0.0f,							1.0f, 0.0f,
			0.0f,							static_cast<float32>(size.y),	0.0f, 1.0f,
			static_cast<float32>(size.x),	static_cast<float32>(size.y),	0.0f, 0.0f,

		    0.0f,							0.0f,							0.0f, 1.0f,
			static_cast<float32>(size.x),	static_cast<float32>(size.y),	1.0f, 0.0f,
			static_cast<float32>(size.x),	0.0f,							1.0f, 1.0f
		};

	glGenBuffers(1, &this->VBO);
	glGenVertexArrays(1, &this->VAO);

	glBindBuffer(GL_ARRAY_BUFFER, this->VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(this->quadV), &this->quadV, GL_STATIC_DRAW);

	glBindVertexArray(this->VAO);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), (void*)0);

	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);
}

void Sprite::clear()
{
	this->shader.use();
	this->shader.setMat4("model", this->model);
	model = glm::mat4(1.0f);
}

void Sprite::draw(const glm::vec2& position, const glm::vec2& scale, const float32& angle)
{
	this->shader.use();
	this->model = glm::mat4(1.0f);
	this->model = glm::translate(this->model, glm::vec3(position, 0.0f));
	this->model = glm::rotate(this->model, glm::radians(angle), glm::vec3(0.0f, 0.0f, 1.0f));
	this->model = glm::scale(this->model, glm::vec3(scale, 1.0f));
	this->shader.setMat4("model", this->model);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, this->texture.ID);
	glBindVertexArray(this->VAO);
	glDrawArrays(GL_TRIANGLES, 0, 6);
	glBindVertexArray(0);
}

glm::ivec4 Sprite::getEdges()
{
	return this->rect;
}

glm::vec2 Sprite::getSize()
{
	return glm::vec2(static_cast<float32>(this->rect.z - this->rect.x) / 2.0f, 
					 static_cast<float32>(this->rect.w - this->rect.y) / 2.0f);
}

Rect Sprite::getBounds()
{
	this->bounds.bottomLeft		= glm::vec2(pos.x - static_cast<float32>(this->rect.z - this->rect.x) / 2.0f,
											pos.y - static_cast<float32>(this->rect.w - this->rect.y) / 2.0f);
	this->bounds.topLeft		= glm::vec2(pos.x - static_cast<float32>(this->rect.z - this->rect.x) / 2.0f,
											pos.y + static_cast<float32>(this->rect.w - this->rect.y) / 2.0f);
	this->bounds.topRight		= glm::vec2(pos.x + static_cast<float32>(this->rect.z - this->rect.x) / 2.0f,
											pos.y + static_cast<float32>(this->rect.w - this->rect.y) / 2.0f);
	this->bounds.bottomRight	= glm::vec2(pos.x + static_cast<float32>(this->rect.z - this->rect.x) / 2.0f,
											pos.y - static_cast<float32>(this->rect.w - this->rect.y) / 2.0f);
	return this->bounds;
}


