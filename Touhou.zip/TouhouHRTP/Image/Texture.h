#pragma once

#include "../headers.h"

class Texture
{
public:
	uint32	ID;
	int32	width, 
			height;
	uint32	internalFormat, 
			imageFormat;
	uint32	wrapS, 
			wrapT;
	uint32	filterMin, 
			filterMax;

	Texture();
	void generate		(const uint32& width, const uint32& height, unsigned char* data);
	void texFromImage	(const std::string& filepath);
	void bind			() const;
};
