#include "Game.h"

int main(int argc, char** argv)
{
	Game* game = new Game;
	
	while (game->isRunning())
	{
		game->update();
		game->display();
	}

	delete game;

	return 0;
}

int WinMain(int argc, char** argv) 
{
	main(argc, argv);
}
