#include "Game.h"

Game::Game()
{
	this->initWindow();
	this->initObjects();
}

Game::~Game()
{
	delete _Reimu;
	delete _Ball;
	for (auto& Tile : _Tiles)
		delete Tile;

	delete _Render;
	delete _Screen;

	glfwTerminate();
}

void Game::updateBall()
{
	glm::vec2 pushDir = glm::normalize(this->_Ball->getPos() - this->_Reimu->getPos());
	if (this->_Ball->checkIntersect(*this->_Reimu))
	{
		//std::cout << "spotted\n";
		this->_Ball->setVel(600.0f * pushDir.x, 700.0f);
		//ball->setVel(200.0f * pushDir.x, abs(200.0f * ((int)(pushDir.y * 30.0f) % 3 + 1)) + 10.0f);
	}

	this->_Ball->update(this->_deltaTime);
}

void Game::updatePlayer	()
{
	_Reimu->update(this->_deltaTime);
}

auto Game::isRunning	() -> bool
{
	return (this->_runtimeFlag && !glfwWindowShouldClose(this->_Window));
}

void Game::clear		()
{
	this->_Render->clear();
}

void Game::update		()
{
	float32 currentFrame = static_cast<float32>(glfwGetTime());
	this->_deltaTime = currentFrame - this->_lastFrame;
	this->_lastFrame = currentFrame;

	processInput(this->_Window);
	this->_Render->clear();

	for (uint32 i = 0; i < this->_Tiles.size(); ++i)
	{
		if (this->_Tiles.at(i)->checkIntersect(*this->_Ball))
			this->_Tiles.at(i)->flip();
		this->_Tiles.at(i)->update(this->_deltaTime);
		if (this->_Tiles.at(i)->getFlip())
			this->_Tiles.erase(this->_Tiles.begin() + i);
	}

	this->updatePlayer();
	this->updateBall();
}

void Game::display()
{
	for (auto& tile : _Tiles)
		tile->draw();
	_Reimu->draw();
	_Ball->draw();

	/*==============================*/

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	this->_Render->display();

	glfwPollEvents();
	glfwSwapBuffers(this->_Window);
}

void Game::initWindow()
{
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // for MAC OS X
#endif // __APPLE__

	this->_Window = glfwCreateWindow(this->_WIN_WIDTH, this->_WIN_HEIGHT, this->_TITLE, NULL, NULL);
	glfwMakeContextCurrent(this->_Window);

	if (!this->_Window)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
	}

	glfwSetFramebufferSizeCallback(this->_Window, framebufferSizeCallback);

	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to load GLAD" << std::endl;
	}

	//glfwSetKeyCallback(window, keyCallback);

	glViewport(0, 0, this->_WIN_WIDTH, this->_WIN_HEIGHT);
	//glEnable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	_Screen = new Shader(glsl::vScreen, glsl::fScreen);
	_Render = new RenderWindow(*_Screen, this->_WIN_WIDTH, this->_WIN_HEIGHT);
}

void Game::initObjects()
{
	this->_Reimu	= new Player(this->_Window, this->_SCR_WIDTH, this->_SCR_HEIGHT);
	this->_Ball		= new Ball	(this->_SCR_WIDTH, this->_SCR_HEIGHT);
	for (uint32 i = 0; i < 10; ++i)
		for (uint32 j = 0; j < 10; ++j)
		{
			int32 v = i * 10 + j;
			this->_Tiles.push_back(new Tile(this->_SCR_WIDTH, this->_SCR_HEIGHT, 1));
			this->_Tiles.at(v)->setPos(
				2 * this->_Tiles.at(v)->getSize().x * (i + 1), 
				2 * this->_Tiles.at(v)->getSize().y * (j + 1));
		}

	this->_Reimu->setPos(this->_SCR_WIDTH / 2.0f, this->_Reimu->getSize().y);
	this->_Ball->setPos(this->_SCR_WIDTH / 2.0f, this->_SCR_HEIGHT - 30.0f);
}

void Game::framebufferSizeCallback(GLFWwindow* window, int32 width, int32 height)
{
	glViewport(0, 0, width, height);
}

void Game::processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (_polygonFlag)
		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	else
		glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
}

//void keyCallback(GLFWwindow* window, int32 key, int32 scancode, int32 action, int32 mods)
//{
//	//Game::polygonFlag;
//	if (key == GLFW_KEY_F2 && action == GLFW_PRESS)
//		Game::polygonFlag = !Game::polygonFlag;
//}