#pragma once
namespace glsl
{
	extern const char* vSprite;
	extern const char* fSprite;

	extern const char* vScreen;
	extern const char* fScreen;
}