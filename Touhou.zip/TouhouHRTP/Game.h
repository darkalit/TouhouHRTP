#pragma once

#include "Objects/Player.h"
#include "Objects/Ball.h"
#include "Objects/Tile.h"
#include <stb_image.h>

class Game
{
public:
	Game	();
	~Game	();

	auto isRunning	() -> bool;
	void clear		();
	void update		();
	void display	();

private:	
	GLFWwindow*			_Window;
	Shader*				_Screen;
	RenderWindow*		_Render;

	Player*				_Reimu;
	Ball*				_Ball;
	std::vector<Tile*>	_Tiles;	

	// screen sizes
	const uint32	_WIN_WIDTH	= 1440;
	const uint32	_WIN_HEIGHT = 900;

	const uint32	_SCR_WIDTH	= 640;
	const uint32	_SCR_HEIGHT = 400;

	const char*		_TITLE		= "TOUHOU";

	// frametime vars
	float32	_deltaTime		= 0.0f;
	float32	_lastFrame		= 0.0f;
	float32	_lastTime		= 0.0f;
	int32	_frameCount		= 0;

	float32 _pixelSize		= 1.0f;

	bool	_polygonFlag	= true;
	bool	_runtimeFlag	= true;

	void updateBall		();
	void updatePlayer	();

	void initWindow		();
	//void initTextures();
	void initObjects	();

	static void framebufferSizeCallback(GLFWwindow*, int32, int32);
	//void keyCallback(GLFWwindow*, int32, int32, int32, int32);
	void processInput	(GLFWwindow*);
};

