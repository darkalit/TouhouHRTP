#pragma once

#include "headers.h"

const char* GLErrorToString		(GLenum err);
const char* GLFrameBufferStatus	(GLenum err);
